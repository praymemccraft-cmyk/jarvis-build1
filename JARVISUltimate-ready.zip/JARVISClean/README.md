# JARVIS Ultimate - Android Project

Futuristic Iron Man-style AI assistant built with Kotlin and Jetpack Compose.

## Features Implemented
- Glowing blue HUD with animated Arc Reactor
- Voice listening (tap button, say commands)
- Commands: time, date, battery level, flashlight, YouTube search
- Text-to-speech responses
- Share sheet for Telegram / Instagram (with confirmation note)
- Secure API key storage ready (extend for full AI chat)

## Permissions
Only necessary ones requested at runtime.

## Build Notes
This project was prepared for Android Gradle Plugin 8.3 / Compose.

To build the APK you need Android Studio or a full Android SDK + Gradle environment.
On phone-only: Use AIDE or similar IDE, though modern Compose support may be limited. Best results with a computer.

## API Configuration
For full AI conversation, add your OpenAI-compatible API key in code or settings (use EncryptedSharedPreferences).
Never hardcode keys.

Built as a real Android project. Install the debug APK if provided.

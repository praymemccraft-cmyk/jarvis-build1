package com.jarvis.ultimate

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.jarvis.ultimate.ui.theme.JARVISTheme
import java.text.SimpleDateFormat
import java.util.*

enum class JarvisState { IDLE, LISTENING, PROCESSING, SPEAKING }

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var torchOn = false
    private var cameraManager: CameraManager? = null
    private var cameraId: String? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val audio = results[Manifest.permission.RECORD_AUDIO] == true
        val camera = results[Manifest.permission.CAMERA] == true
        if (audio) {
            startListening()
        } else {
            Toast.makeText(this, "Microphone permission is required for voice commands", Toast.LENGTH_LONG).show()
        }
        if (!camera && torchOn) {
            // Will be re-checked on next flashlight command
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            cameraId = cameraManager?.cameraIdList?.firstOrNull()
        } catch (_: Exception) {}

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
            }
        }

        setContent {
            JARVISTheme {
                var state by remember { mutableStateOf(JarvisState.IDLE) }
                var statusText by remember { mutableStateOf("Ready") }

                JarvisScreen(
                    state = state,
                    statusText = statusText,
                    onListen = {
                        state = JarvisState.LISTENING
                        statusText = "Listening..."
                        checkAndStartListening { newState, text ->
                            state = newState
                            statusText = text
                        }
                    }
                )
            }
        }
    }

    private fun checkAndStartListening(onState: (JarvisState, String) -> Unit) {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CAMERA)
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
            return
        }
        startListening(onState)
    }

    private fun startListening(onState: (JarvisState, String) -> Unit = { _, _ -> }) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available on this device.")
            onState(JarvisState.IDLE, "Speech recognition unavailable")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                onState(JarvisState.LISTENING, "Listening...")
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                onState(JarvisState.PROCESSING, "Processing...")
            }
            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "I didn't catch that. Please try again."
                    SpeechRecognizer.ERROR_NETWORK -> "Network error for speech recognition."
                    else -> "Speech error. Please try again."
                }
                speak(msg)
                onState(JarvisState.IDLE, msg)
            }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                onState(JarvisState.PROCESSING, "Heard: $spoken")
                handleCommand(spoken, onState)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        speechRecognizer?.startListening(intent)
    }

    private fun speak(text: String, onDone: (() -> Unit)? = null) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        // Simple callback approximation
        android.os.Handler(mainLooper).postDelayed({
            onDone?.invoke()
        }, (text.length * 60L).coerceAtLeast(800L))
    }

    private fun handleCommand(command: String, onState: (JarvisState, String) -> Unit) {
        val lower = command.lowercase(Locale.getDefault()).trim()
        onState(JarvisState.PROCESSING, "Processing command...")

        when {
            // Flashlight
            lower.contains("flashlight") || lower.contains("torch") || lower.contains("fonar") || lower.contains("chiroq") -> {
                val turnOn = lower.contains("on") || lower.contains("yoq") || lower.contains("enable") ||
                        (!lower.contains("off") && !lower.contains("o'chir") && !lower.contains("disable"))
                val success = setFlashlight(turnOn)
                val reply = if (success) {
                    if (turnOn) "Flashlight is on." else "Flashlight is off."
                } else {
                    "I could not control the flashlight."
                }
                speak(reply) { onState(JarvisState.IDLE, reply) }
            }

            // Time
            lower.contains("time") || lower.contains("vaqt") || lower.contains("soat") -> {
                val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                val reply = "The time is $time"
                speak(reply) { onState(JarvisState.IDLE, reply) }
            }

            // Date
            lower.contains("date") || lower.contains("sana") -> {
                val date = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())
                val reply = "Today is $date"
                speak(reply) { onState(JarvisState.IDLE, reply) }
            }

            // Battery
            lower.contains("battery") || lower.contains("batareya") || lower.contains("zaryad") -> {
                val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                val reply = "Battery is at $level percent"
                speak(reply) { onState(JarvisState.IDLE, reply) }
            }

            // YouTube search
            lower.contains("youtube") && (lower.contains("search") || lower.contains("qidir") || lower.contains("for")) -> {
                val query = extractQuery(lower, listOf("search", "for", "youtube", "qidir"))
                openYouTube(query)
                val reply = "Opening YouTube search for $query"
                speak(reply) { onState(JarvisState.IDLE, reply) }
            }

            // Open apps
            lower.contains("open youtube") || lower.contains("youtube och") -> {
                openApp("com.google.android.youtube", "YouTube")
                onState(JarvisState.IDLE, "Opening YouTube")
            }
            lower.contains("open instagram") || lower.contains("instagram och") -> {
                openApp("com.instagram.android", "Instagram")
                onState(JarvisState.IDLE, "Opening Instagram")
            }
            lower.contains("open telegram") || lower.contains("telegram och") -> {
                openApp("org.telegram.messenger", "Telegram")
                onState(JarvisState.IDLE, "Opening Telegram")
            }

            // Stop
            lower.contains("stop") || lower.contains("to'xta") || lower.contains("stop listening") -> {
                speechRecognizer?.stopListening()
                val reply = "Stopped listening."
                speak(reply) { onState(JarvisState.IDLE, reply) }
            }

            // Repeat
            lower.contains("repeat") || lower.contains("takror") -> {
                speak("I don't have a previous message stored yet.") { onState(JarvisState.IDLE, "Ready") }
            }

            else -> {
                val reply = "I heard: $command. Try saying turn on flashlight, what time is it, or open YouTube."
                speak(reply) { onState(JarvisState.IDLE, reply) }
            }
        }
    }

    private fun setFlashlight(on: Boolean): Boolean {
        return try {
            val id = cameraId ?: return false
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                speak("Camera permission is needed for the flashlight.")
                return false
            }
            cameraManager?.setTorchMode(id, on)
            torchOn = on
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun openYouTube(query: String) {
        val clean = query.ifBlank { "Minecraft" }
        try {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", clean)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        } catch (_: Exception) {
            val uri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(clean)}")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    private fun openApp(packageName: String, displayName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            startActivity(launch)
            speak("Opening $displayName")
        } else {
            speak("$displayName is not installed.")
        }
    }

    private fun extractQuery(text: String, keywords: List<String>): String {
        var result = text
        keywords.forEach { result = result.replace(it, "") }
        return result.trim().replace(Regex("\\s+"), " ")
    }

    override fun onDestroy() {
        tts?.shutdown()
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}

@Composable
fun JarvisScreen(
    state: JarvisState,
    statusText: String,
    onListen: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "reactor")
    val pulse by infiniteTransition.animateFloat(
        initialValue = if (state == JarvisState.LISTENING) 0.7f else 0.85f,
        targetValue = if (state == JarvisState.LISTENING) 1.3f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (state == JarvisState.LISTENING) 600 else 1400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val color = when (state) {
        JarvisState.LISTENING -> Color(0xFF00FFFF)
        JarvisState.PROCESSING -> Color(0xFFFFAA00)
        JarvisState.SPEAKING -> Color(0xFF00FF88)
        else -> Color(0xFF00BFFF)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("JARVIS ULTIMATE", color = Color(0xFF00BFFF), fontSize = 26.sp)
        Spacer(Modifier.height(8.dp))
        Text(statusText, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)

        Spacer(Modifier.height(24.dp))

        Canvas(modifier = Modifier.size(180.dp)) {
            val center = Offset(size.width / 2, size.height / 2)
            drawCircle(color.copy(alpha = 0.25f), radius = 85f * pulse, center = center)
            drawCircle(color, radius = 65f, center = center, style = Stroke(6f))
            drawCircle(color.copy(alpha = 0.9f), radius = 35f * pulse, center = center)
            drawCircle(Color.White.copy(alpha = 0.9f), radius = 12f, center = center)
        }

        Spacer(Modifier.height(32.dp))

        Button(
            onClick = onListen,
            colors = ButtonDefaults.buttonColors(containerColor = color),
            modifier = Modifier.height(56.dp)
        ) {
            Text(
                when (state) {
                    JarvisState.LISTENING -> "Listening..."
                    JarvisState.PROCESSING -> "Processing..."
                    else -> "Hey JARVIS"
                },
                color = Color.Black,
                fontSize = 18.sp
            )
        }

        Spacer(Modifier.height(12.dp))
        Text(
            "Try: turn on flashlight • what time is it • open YouTube",
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 12.sp
        )
    }
}

package com.jarvis.ultimate

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.jarvis.ultimate.ui.theme.JARVISTheme
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.RECORD_AUDIO] == true) {
            startListening()
        } else {
            Toast.makeText(this, "Microphone permission required", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
            }
        }
        setContent {
            JARVISTheme {
                JarvisScreen(
                    onListen = { checkAndStartListening() },
                    onSpeak = { text -> speak(text) },
                    onAction = { command -> handleCommand(command) }
                )
            }
        }
    }

    private fun checkAndStartListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startListening()
        } else {
            requestPermissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
        }
    }

    private fun startListening() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Hey JARVIS, listening...")
            }
            speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    speak("Sorry, I didn't catch that.")
                }
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = matches?.getOrNull(0) ?: ""
                    handleCommand(spoken)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            speechRecognizer?.startListening(intent)
        } else {
            Toast.makeText(this, "Speech recognition not available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    private fun handleCommand(command: String) {
        val lower = command.lowercase(Locale.getDefault())
        when {
            lower.contains("time") -> {
                val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                speak("The time is $time")
            }
            lower.contains("date") -> {
                val date = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date())
                speak("Today is $date")
            }
            lower.contains("battery") -> {
                val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                speak("Battery is at $level percent")
            }
            lower.contains("flashlight") || lower.contains("torch") -> {
                toggleFlashlight()
                speak("Flashlight toggled")
            }
            lower.contains("youtube") || lower.contains("search") -> {
                val query = command.substringAfter("search", command).trim()
                openYouTube(query)
                speak("Opening YouTube search for $query")
            }
            lower.contains("write this message") || lower.contains("write message") -> {
                // Show dialog or toast with transcribed text for editing
                Toast.makeText(this, "Transcribed: $command", Toast.LENGTH_LONG).show()
                speak("Message transcribed. You can edit it.")
            }
            lower.contains("telegram") || lower.contains("instagram") -> {
                // Trigger share intent with confirmation
                shareToApp(lower)
            }
            else -> {
                // Fallback to AI if configured, else simple reply
                speak("I heard: $command. Core actions available: time, date, battery, flashlight, YouTube search.")
            }
        }
    }

    private fun toggleFlashlight() {
        try {
            val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList[0]
            cameraManager.setTorchMode(cameraId, true) // Simple toggle logic can be expanded
            // Note: For real toggle, track state
        } catch (e: Exception) {
            speak("Unable to control flashlight")
        }
    }

    private fun openYouTube(query: String) {
        val intent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra("query", query)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // Fallback to browser
            val browser = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com/results?search_query=$query"))
            startActivity(browser)
        }
    }

    private fun shareToApp(command: String) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Message from JARVIS")
        }
        val chooser = Intent.createChooser(shareIntent, "Share via")
        startActivity(chooser)
        speak("Please confirm and select the contact in the share sheet. I never send without your confirmation.")
    }

    override fun onDestroy() {
        tts?.shutdown()
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}

@Composable
fun JarvisScreen(
    onListen: () -> Unit,
    onSpeak: (String) -> Unit,
    onAction: (String) -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arc")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "JARVIS ULTIMATE",
            color = Color(0xFF00BFFF),
            fontSize = 28.sp,
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(32.dp))

        // Animated Arc Reactor
        Canvas(modifier = Modifier.size(200.dp)) {
            val center = Offset(size.width / 2, size.height / 2)
            drawCircle(color = Color(0xFF00BFFF).copy(alpha = 0.3f), radius = 90f * pulse, center = center)
            drawCircle(color = Color(0xFF1E90FF), radius = 70f, center = center, style = Stroke(width = 8f))
            drawCircle(color = Color(0xFF00BFFF), radius = 40f * pulse, center = center)
            drawCircle(color = Color.White.copy(alpha = 0.8f), radius = 15f, center = center)
        }

        Spacer(modifier = Modifier.height(48.dp))

        Button(
            onClick = onListen,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00BFFF))
        ) {
            Text("Hey JARVIS - Listen", color = Color.Black)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Say: time, date, battery, flashlight, search YouTube...",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 14.sp
        )
    }
}

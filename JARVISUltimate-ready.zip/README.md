# JARVIS Ultimate

Futuristic personal AI assistant (Kotlin + Jetpack Compose).

## Current Features (offline for basic commands)
- Voice commands via Android SpeechRecognizer (tap the button)
- Text-to-speech replies
- Flashlight **toggle** (on/off with state tracking)
- Time, date, battery
- Open YouTube / Instagram / Telegram
- YouTube search
- Share sheet for messaging (user must confirm)
- Animated Arc Reactor with listening / processing / speaking states
- Basic Uzbek keyword support (fonar, vaqt, och, etc.)

## Permissions
- Microphone (required for voice)
- Camera (required for flashlight on most devices)

## Phone-only Build Options
1. **AndroidBuild.com** (recommended for phone-only)
   - Upload this ZIP
   - Free tier: 2 debug APK builds / month
   - Supports native Kotlin Gradle projects

2. AIDE (Android IDE) — limited Compose support; may need simplification.

Debug APK can be sideloaded on Redmi 14C (enable Install unknown apps).

## Notes
- Basic commands work fully offline.
- Full conversational AI requires a future configurable provider (not hardcoded).
- Flashlight now correctly turns on **and** off.
- No silent message sending. Confirmation is required.
